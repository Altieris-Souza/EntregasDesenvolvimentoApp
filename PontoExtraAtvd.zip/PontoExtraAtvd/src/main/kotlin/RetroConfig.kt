import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetroConfig {
    private var retro = Retrofit.Builder()
    .baseUrl("https://investidor10.com.br/api/")
    .addConverterFactory(GsonConverterFactory.create())
    .build()

    fun getService(): InvestidorService{
        return this.retro.create(InvestidorService::class.java)
    }
}