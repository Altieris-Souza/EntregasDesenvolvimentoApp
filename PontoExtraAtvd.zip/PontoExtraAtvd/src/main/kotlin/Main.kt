import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



fun main() {
    val call: Call<CotacaoResponse> = RetroConfig().getService().obterAcao("VALE3")
    call.enqueue(object : Callback<CotacaoResponse> {
        override fun onResponse(call: Call<CotacaoResponse?>, response: Response<CotacaoResponse?>) {
            val body = response.body()
            if (body?.reais != null) {
                println("Preço da ação: ${body.reais[0].price}")
            }
        }

        override fun onFailure(p0: Call<CotacaoResponse?>, p1: Throwable) {
            println("Erro: ${p1.message}")
        }
    })
}