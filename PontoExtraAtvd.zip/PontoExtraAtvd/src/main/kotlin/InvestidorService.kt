import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface InvestidorService {
    @GET("cotacoes/acao/chart/{codigo}/1/true/real")
    fun obterAcao(@Path("codigo") codigo: String): Call<String>
}