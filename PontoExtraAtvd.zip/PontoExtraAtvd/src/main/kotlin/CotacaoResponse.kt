data class CotacaoResponse(
    val reais: List<Reais>
)

data class Reais(
    val price: Double
)