package com.example.fichacriacaopersonagem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import org.example.Breeds.Anao
import org.example.Breeds.Draconato
import org.example.Breeds.Elfo
import org.example.Breeds.Gnomo
import org.example.Breeds.Halfing
import org.example.Breeds.Humano
import org.example.Breeds.IBreeds
import org.example.Breeds.MeioElfo
import org.example.Breeds.MeioOrc
import org.example.Breeds.Tiefling
import org.example.Character.Attribute
import org.example.Classes.Barbaro
import org.example.Classes.IClasses
import org.example.Classes.Mago

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CharacterCreationApp()
        }
    }
}

@Composable
fun CharacterCreationApp() {
    var nomePersonagem by remember { mutableStateOf("") }
    var raçaSelecionada by remember { mutableStateOf("") }
    var classeSelecionada by remember { mutableStateOf("") }
    var atributos by remember { mutableStateOf(emptyList<Int>()) }
    var passoAtual by remember { mutableStateOf(1) }

    when (passoAtual) {

        1 -> TelaRaca(onNext = {
            passoAtual = 2
        }, onRaceSelect = { raça -> raçaSelecionada = raça.getRaceName() })
        2 -> TelaClasse(onNext = {
            passoAtual = 3
        }, onClassSelect = { classePersonagem -> classeSelecionada = classePersonagem.getClassName() })
        3 -> TelaAtributos(onNext = {
            passoAtual = 4
            atributos = it
        })
        4 -> TelaNome(onNext = {
            passoAtual = 5
        }, onNameChange = { nome -> nomePersonagem = nome })
        5 -> TelaResumo(
            nomePersonagem = nomePersonagem,
            raçaPersonagem = raçaSelecionada,
            classePersonagem = classeSelecionada,
            atributos = atributos
        )
    }
}

@Composable
fun TelaNome(onNext: () -> Unit, onNameChange: (String) -> Unit) {
    var nomePersonagem by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Digite o Nome do Personagem", fontSize = 30.sp)
        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = nomePersonagem,
            onValueChange = {
                nomePersonagem = it
                onNameChange(it)
            },
            placeholder = { Text("Nome do Personagem") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { onNext() }) {
            Text("Próximo: Escolher Raça", fontSize = 24.sp)
        }
    }
}

@Composable
fun TelaRaca(onNext: () -> Unit, onRaceSelect: (IBreeds) -> Unit) {
    val racas = listOf(Anao(), Elfo(), Humano(), Draconato(), Gnomo(), Halfing(), MeioElfo(), MeioOrc(), Tiefling())

    var racaSelecionada by remember { mutableStateOf<IBreeds?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text("Selecione a Raça do Personagem", fontSize = 30.sp)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(racas) { raca ->
                ItemRaca(raca = raca, isSelected = (racaSelecionada == raca)) {
                    racaSelecionada = raca
                    onRaceSelect(raca)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            racaSelecionada?.let {
                onNext()
            }
        }, enabled = racaSelecionada != null) {
            Text("Próximo: Escolher Classe", fontSize = 24.sp)
        }
    }
}

@Composable
fun ItemRaca(raca: IBreeds, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onClick() }
            .padding(16.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(raca.getRaceName(), fontSize = 24.sp)
        if (isSelected) {
            // Indicar que a raça está selecionada (opcional)
            Text("✓", fontSize = 24.sp, modifier = Modifier.padding(start = 8.dp))
        }
    }
}


@Composable
fun TelaClasse(onNext: () -> Unit, onClassSelect: (IClasses) -> Unit) {
    val classes = listOf(Barbaro(), Mago())

    var classeSelecionada by remember { mutableStateOf<IClasses?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text("Selecione a Classe do Personagem", fontSize = 30.sp)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(classes) { classe ->
                ItemClasse(classePersonagem = classe, isSelected = (classeSelecionada == classe)) {
                    classeSelecionada = classe
                    onClassSelect(classe)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            classeSelecionada?.let { onNext() }
        }, enabled = classeSelecionada != null) {
            Text("Próximo: Distribuir Atributos", fontSize = 24.sp)
        }
    }
}

@Composable
fun ItemClasse(classePersonagem: IClasses, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onClick() }
            .padding(16.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(classePersonagem.getClassName(), fontSize = 24.sp)
        if (isSelected) {
            Text("✓", fontSize = 24.sp, modifier = Modifier.padding(start = 8.dp))
        }
    }
}
@Composable
fun TelaAtributos(onNext: (List<Int>) -> Unit) {
    val nomesAtributos = listOf("Força", "Destreza", "Constituição", "Inteligência", "Sabedoria", "Carisma")
    val pontosIniciais = 27
    var pontosRestantes by remember { mutableStateOf(pontosIniciais) }

    val atributos = remember { mutableStateListOf(8, 8, 8, 8, 8, 8) }

    fun custoParaAumentar(valor: Int): Int {
        return when (valor) {
            8 -> 1
            9 -> 1
            10 -> 1
            11 -> 1
            12 -> 1
            13 -> 2
            14 -> 2
            else -> 0
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text("Distribuir Atributos do Personagem", fontSize = 30.sp)
        Spacer(modifier = Modifier.height(16.dp))

        nomesAtributos.forEachIndexed { index, nome ->
            ItemAtributo(
                nome = nome,
                valor = atributos[index],
                onIncrease = {
                    val valorAtual = atributos[index]
                    val custo = custoParaAumentar(valorAtual)

                    if (pontosRestantes >= custo && valorAtual < 15) {
                        pontosRestantes -= custo
                        atributos[index]++
                    }
                },
                onDecrease = {
                    val valorAtual = atributos[index]
                    if (valorAtual > 8) {
                        val custo = custoParaAumentar(valorAtual - 1)
                        pontosRestantes += custo
                        atributos[index]--
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Pontos Restantes: $pontosRestantes", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                onNext(atributos.toList())
            },
            enabled = pontosRestantes == 0
        ) {
            Text("Próximo: Revisar Resumo", fontSize = 24.sp)
        }
    }
}

@Composable
fun ItemAtributo(nome: String, valor: Int, onIncrease: () -> Unit, onDecrease: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("$nome: $valor", modifier = Modifier.weight(1f), fontSize = 24.sp)
        Button(onClick = onDecrease) {
            Text("-")
        }
        Button(onClick = onIncrease) {
            Text("+")
        }
    }
}

@Composable
fun TelaResumo(
    nomePersonagem: String,
    raçaPersonagem: String,
    classePersonagem: String,
    atributos: List<Int>
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text("Resumo do Personagem", fontSize = 30.sp)
        Spacer(modifier = Modifier.height(16.dp))

        Text("Nome: $nomePersonagem", fontSize = 24.sp)
        Text("Raça: $raçaPersonagem", fontSize = 24.sp)
        Text("Classe: $classePersonagem", fontSize = 24.sp)
        Text("Atributos:", fontSize = 24.sp)

        val nomesAtributos = listOf("Força", "Destreza", "Constituição", "Inteligência", "Sabedoria", "Carisma")

        nomesAtributos.forEachIndexed { index, nome ->
            Text("$nome: ${atributos[index]}", fontSize = 20.sp)
        }
    }
}